


SELECT Table_Name, 
    Column_Name
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_CATALOG = 'gcmis'
   AND COLUMN_NAME LIKE 'ItemCode%';



   select distinct concode from GWCONTRACT    
    select distinct concode from GWCONTDETL    
	   select distinct concode from GWCONTDETL   

 



select distinct itemcode  from GWFeesd
 











select * from ACMJOURD






select * from GWCONTRACT
select * from RECO
select * from AWMORDERH
select * from AWMCONTRACTa
select * from AWMAWM_LB
select * from AWMCONTHSS
select * from AWMCondCalr
select * from AHMBYPASS
select * from awmcontdlx_old
select * from AWMCONTDLX
select * from AHMCHEQ
select * from AWMCONTRACTZ
select * from ACMPRDTC
select * from AWMConUser
select * from AWMBYP
select * from AWMBYP
select * from AWMCONTATT
select * from AWMCHEQ
select * from AWMCONALTH
select * from AWMCONPAYD
select * from AWMCONPAYO
select * from AWMCONPAYT
select * from AWMCONQDETL
select * from AWMCONQRY
select * from AWMCONTDD
select * from AWMCONTDETL
select * from AWMCONTDS
select * from AWMCONTHS
select * from AWMCONTPDD
select * from AWMCONTRACT
select * from AWMDITEM
select * from AWMH_CON1
select * from AWMH_CON2
select * from AWMINPDETL
select * from AWMINPDTLD
select * from AWMINPDTLH
select * from AWMINSB
select * from AWMINVOICE
select * from AHMINV
select * from AWMBYPASS
select * from AWMBYPASS
select * from ACMSALEH
