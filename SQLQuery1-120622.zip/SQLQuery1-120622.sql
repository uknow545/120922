

select * from ACMATT 
select * from ACMBANK 
select * from ACMBANKLIST 
select * from ACMBANKNUM 
select * from ACMBANKS 
select * from ACMBTOB 
select * from ACMBUDGET ORDER BY NAME 

select CorpSno	,Code	,Kind	,Chkno	,Chkdate	,Money,	Bank,	Account,	Note,	Prdt
 from ACMCASH

--select CorpSno	,Code	,Kind	,Chkno	,Chkdate	,Money,	Bank,	Account,	Note,	Prdt 
--from ACMCASHPH
select * from ACMCASHPH
select * from ACMCASHPRED
select * from ACMCHKB 
select * from ACMCOMMAPP